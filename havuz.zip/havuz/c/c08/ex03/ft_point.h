/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_point.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rdemiray <rdemiray@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/12 05:10:36 by rdemiray          #+#    #+#             */
/*   Updated: 2023/04/12 05:11:30 by rdemiray         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_POINT_H
# define FT_BOOLEAN_H

typedef struct a_point
{
	int	x;
	int	y;
}	t_point;

void	set_point(t_point *point);

#endif
