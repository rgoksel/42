/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rdemiray <rdemiray@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/11 18:30:56 by rdemiray          #+#    #+#             */
/*   Updated: 2023/04/12 01:23:16 by rdemiray         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int	*a;
	int	r;
	int	i;

	i = 0;
	r = max - min;
	a = (int *) malloc(r * sizeof(int));
	if (min >= max)
	{
		*range = 0;
		return (0);
	}
	if (!a)
	{
		*range = 0;
		return (-1);
	}
	*range = a;
	i = 0;
	while (i < r)
	{
		a[i] = min + i;
		i++;
	}
	return (r);
}
