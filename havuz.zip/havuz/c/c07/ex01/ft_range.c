/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rdemiray <rdemiray@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/11 17:25:40 by rdemiray          #+#    #+#             */
/*   Updated: 2023/04/12 01:22:56 by rdemiray         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	*a;
	int	r;
	int	i;

	i = 0;
	r = max - min;
	a = (int *) malloc(r * sizeof(int));
	if (min >= max)
		return (0);
	while (i < r)
	{
		a[i] = min + i;
		i++;
	}
	return (a);
}
