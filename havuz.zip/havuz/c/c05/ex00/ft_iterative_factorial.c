/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rdemiray <rdemiray@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/10 11:41:34 by rdemiray          #+#    #+#             */
/*   Updated: 2023/04/10 11:41:54 by rdemiray         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial(int nb)
{
	unsigned int	son;

	son = 1;
	if (nb < 0)
		return (0);
	while (nb > 0)
	{
		son *= nb;
		nb--;
	}
	return (son);
}
