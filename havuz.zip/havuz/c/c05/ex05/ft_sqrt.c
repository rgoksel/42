/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rdemiray <rdemiray@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/10 16:55:26 by rdemiray          #+#    #+#             */
/*   Updated: 2023/04/11 13:58:32 by rdemiray         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_sqrt(int nb)
{
	long	a;
	long	son;

	a = 2;
	son = nb;
	if (son <= 0)
		return (0);
	if (son == 1)
		return (1);
	if (son >= 2)
	{
		while (a * a <= son)
		{
			if (a * a == son)
				return (a);
			a++;
		}
	}
	return (0);
}
