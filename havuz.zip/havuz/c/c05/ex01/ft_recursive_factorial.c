/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rdemiray <rdemiray@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/10 12:11:10 by rdemiray          #+#    #+#             */
/*   Updated: 2023/04/10 18:26:23 by rdemiray         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_recursive_factorial(int nb)
{
	int	son;

	son = 1;
	if (nb > 0)
	{
		son *= nb * ft_recursive_factorial(nb - 1);
		nb --;
	}
	if (nb < 0)
		return (0);
	return (son);
}
