/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rdemiray <rdemiray@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/10 18:26:45 by rdemiray          #+#    #+#             */
/*   Updated: 2023/04/10 18:31:35 by rdemiray         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_power(int nb, int power)
{
	unsigned int	son;

	son = nb;
	while (power > 1)
	{
		son *= nb;
		power --;
	}
	if (power == 0)
		return (1);
	if (power < 0)
		return (0);
	return (son);
}
