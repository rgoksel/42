/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rdemiray <rdemiray@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/05 15:18:34 by rdemiray          #+#    #+#             */
/*   Updated: 2023/04/08 16:15:07 by rdemiray         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int	ft_strlen(char	*str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		i++;
	}
	return (i);
}

int	hata1(char *base)
{
	int	i;
	int	len;
	int	j;

	i = 0;
	len = ft_strlen(base);
	if (base[i] == '\0' || len == 1)
		return (0);
	while (base[i] != '\0')
	{
		if (base[i] == '+' || base[i] == '-' || base[i] == 127 || base[i] <= 32)
			return (0);
		j = i + 1;
		while (j < len)
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	return (1);
}

void	ft_putnbr_base(int nbr, char *base)
{
	int		len;
	int		hata;
	long	sayi;

	sayi = nbr;
	hata = hata1(base);
	len = ft_strlen(base);
	if (hata == 1)
	{
		if (sayi < 0)
		{
			ft_putchar('-');
			sayi = -sayi;
		}
		if (sayi > len)
		{
			ft_putnbr_base(sayi / len, base);
			ft_putnbr_base(sayi % len, base);
		}
		else
			ft_putchar(base[sayi]);
	}
}
