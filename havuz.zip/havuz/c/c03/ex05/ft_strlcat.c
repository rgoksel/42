/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rdemiray <rdemiray@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/02 18:00:29 by rdemiray          #+#    #+#             */
/*   Updated: 2023/04/02 18:00:36 by rdemiray         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	unsigned int	dst;
	unsigned int	sr;

	i = 0;
	dst = ft_strlen(dest);
	sr = ft_strlen(src);
	if (size == 0 || size <= dst)
		return (sr + size);
	while (src [i] != '\0' && dst + i < size - 1)
	{
		dest[dst + i] = src[i];
		i++;
	}
	dest[dst + i] = '\0';
	return (dst + sr);
}
