/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rdemiray <rdemiray@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/02 14:44:11 by rdemiray          #+#    #+#             */
/*   Updated: 2023/04/12 16:41:40 by rdemiray         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strstr(char *str, char *to_find)
{
	int i;
	int a;

	
	i= 0;
	while(str[i] != '\0')
	{
		a = 0;
		if(str[i] == to_find[a])
		{
			while (to_find[a] != '\0')
			{	
				a++;
			}
		}
		i++;
	}
}


int main()
{
	printf("%s\n", ft_strstr("göksel", "se"));
	return 0;
}
